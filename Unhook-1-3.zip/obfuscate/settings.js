let defaultSettings = {
  overrideDuration: 60,
  overrideDelay: 5,
  allowOverride: true,
  blockList: ['facebook.com', 'reddit.com', 'twitter.com'],
  isLicensed: true
}